# NEXO.GG — projeto inicial

Um protótipo responsivo de comunidade gaming com quizzes sobre Fortnite, gaming e tecnologia, contas de utilizador e ranking.

## Ficheiros
- `index.html` — site e interface do quiz.
- `supabase_schema.sql` — tabelas, regras de segurança (RLS), perfil automático e vista do ranking.
- `README.md` — este guia.

## Ver a demonstração
Abre `index.html` no navegador. Sem configuração do Supabase, o quiz funciona localmente e o ranking usa nomes demonstrativos. As contas reais e a gravação online só funcionam depois de configurar a base de dados.

## Ativar contas e base de dados
1. Cria um projeto em https://supabase.com/.
2. No painel do projeto, abre **SQL Editor**, cola o conteúdo de `supabase_schema.sql` e executa.
3. Vai a **Project Settings → API** (ou Connect) e copia o Project URL e a chave pública `anon`/publishable.
4. Abre `index.html` num editor de texto e preenche:
   ```js
   const SUPABASE_URL = 'https://TEU-PROJETO.supabase.co';
   const SUPABASE_ANON_KEY = 'A_TUA_CHAVE_PUBLICA';
   ```
   Nunca uses a chave `service_role` no navegador.
5. Em Authentication, configura confirmação de email e URLs permitidos para o teu domínio.
6. Publica o site num alojamento estático, por exemplo Netlify, Vercel ou Cloudflare Pages. Para módulos ES e autenticação, testa através de um servidor local ou alojamento, em vez de abrir por `file://`.

## Estado e limitações deste starter
- Registo e login com email/password através do Supabase.
- Os resultados são gravados online quando há sessão iniciada.
- O ranking consulta uma vista SQL pública que mostra apenas nomes e pontos.
- O perfil e o resultado são um ponto de partida; antes de abrir ao público, adiciona validação anti-abuso no servidor, limites de tentativas, recuperação de palavra-passe, regras de moderação e testes de segurança.
- O ranking soma pontos de todos os resultados e pode ser explorado por utilizadores que repitam quizzes. Para produção, define regras (por exemplo, melhor resultado por quiz e por dia) e aplica-as no servidor.
- Não recolhas dados pessoais desnecessários. Se o público incluir menores, revê privacidade, consentimento, regras do alojamento e requisitos legais aplicáveis.
- O nome NEXO.GG é provisório; verifica disponibilidade de domínio e marca antes de investir.

## Ideias para a versão seguinte
1. Desafio diário e sequência de dias.
2. Perfis com avatar, nível e emblemas.
3. Painel de administração para gerir perguntas.
4. Desafios entre amigos com códigos.
5. Conteúdo original e guias de gaming, com divulgação orgânica.
6. Monetização só depois de criar uma comunidade: patrocínios, publicidade apropriada e links de afiliados claramente identificados.

O NEXO.GG é um projeto independente de fãs e não é afiliado à Epic Games. Fortnite é uma marca da Epic Games.
